from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import joblib
import json
import os
import pandas as pd

app = FastAPI(title="House Price Prediction API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model = None
locations_data = []

class PredictRequest(BaseModel):
    location: str
    carpet_area_sqft: float
    floor_num: int
    bathroom: int
    balcony: int
    furnishing: str
    transaction: str
    ownership: str
    facing: str

@app.on_event("startup")
async def load_assets():
    global model, locations_data
    
    model_path = os.path.join(os.path.dirname(__file__), "models", "house_price.pkl")
    if os.path.exists(model_path):
        try:
            model = joblib.load(model_path)
            print("Model loaded successfully.")
        except Exception as e:
            print(f"Error loading model: {e}")
    else:
        print("Warning: Model file not found.")

    locations_path = os.path.join(os.path.dirname(__file__), "models", "locations.json")
    if os.path.exists(locations_path):
        try:
            with open(locations_path, "r") as f:
                data = json.load(f)
                locations_data = data.get("locations", [])
            print("Locations loaded successfully.")
        except Exception as e:
            print(f"Error loading locations: {e}")
    else:
        print("Warning: Locations file not found.")

@app.get("/health")
def health_check():
    return {"status": "ok"}

@app.get("/locations")
def get_locations():
    return {"locations": locations_data}

@app.post("/predict")
def predict_price(request: PredictRequest):
    if model is None:
        raise HTTPException(status_code=503, detail="Model is not loaded")
    
    # Create a 1-row DataFrame matching the training data columns
    df = pd.DataFrame([{
        "location_grouped": request.location,
        "carpet_area_sqft": request.carpet_area_sqft,
        "floor_num": request.floor_num,
        "Bathroom": request.bathroom,
        "Balcony": request.balcony,
        "Furnishing": request.furnishing,
        "Transaction": request.transaction,
        "Ownership": request.ownership,
        "facing": request.facing
    }])
    
    try:
        prediction = model.predict(df)
        return {"predicted_price": float(prediction[0])}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
