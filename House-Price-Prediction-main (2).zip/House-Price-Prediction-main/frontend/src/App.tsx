import { useState, useEffect, FormEvent } from 'react'
import './App.css'

interface PredictionResponse {
  predicted_price: number;
}

interface LocationsResponse {
  locations: string[];
}

function App() {
  const [locations, setLocations] = useState<string[]>([]);
  
  const [carpetAreaSqft, setCarpetAreaSqft] = useState<string>('');
  const [floorNum, setFloorNum] = useState<string>('');
  const [bathroom, setBathroom] = useState<string>('');
  const [balcony, setBalcony] = useState<string>('');
  
  const [location, setLocation] = useState<string>('');
  const [furnishing, setFurnishing] = useState<string>('Unfurnished');
  const [transaction, setTransaction] = useState<string>('Resale');
  const [ownership, setOwnership] = useState<string>('Freehold');
  const [facing, setFacing] = useState<string>('East');

  const [predictedPrice, setPredictedPrice] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    fetch('http://localhost:8000/locations')
      .then(res => res.json())
      .then((data: LocationsResponse) => {
        if (data.locations && data.locations.length > 0) {
          setLocations(data.locations);
          setLocation(data.locations[0]);
        }
      })
      .catch(err => {
        console.error("Error fetching locations:", err);
      });
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setPredictedPrice(null);
    setLoading(true);

    try {
      const response = await fetch('http://localhost:8000/predict', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          location,
          carpet_area_sqft: parseFloat(carpetAreaSqft),
          floor_num: parseInt(floorNum),
          bathroom: parseInt(bathroom),
          balcony: parseInt(balcony),
          furnishing,
          transaction,
          ownership,
          facing
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data: PredictionResponse = await response.json();
      setPredictedPrice(data.predicted_price);
    } catch (err: any) {
      setError(err.message || 'An error occurred during prediction');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>House Price Prediction</h1>
      
      <form onSubmit={handleSubmit} className="form-card">
        <div className="form-row">
          <div className="form-group">
            <label>Carpet Area (sqft)</label>
            <input 
              type="number" 
              value={carpetAreaSqft} 
              onChange={(e) => setCarpetAreaSqft(e.target.value)} 
              placeholder="e.g. 1500" 
              required 
            />
          </div>
          
          <div className="form-group">
            <label>Floor Number</label>
            <input 
              type="number" 
              value={floorNum} 
              onChange={(e) => setFloorNum(e.target.value)} 
              placeholder="e.g. 3" 
              required 
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Bathrooms</label>
            <input 
              type="number" 
              value={bathroom} 
              onChange={(e) => setBathroom(e.target.value)} 
              placeholder="e.g. 2" 
              required 
            />
          </div>

          <div className="form-group">
            <label>Balconies</label>
            <input 
              type="number" 
              value={balcony} 
              onChange={(e) => setBalcony(e.target.value)} 
              placeholder="e.g. 1" 
              required 
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Location</label>
            <select 
              value={location} 
              onChange={(e) => setLocation(e.target.value)} 
              required
            >
              {locations.map(loc => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Furnishing</label>
            <select value={furnishing} onChange={(e) => setFurnishing(e.target.value)} required>
              <option value="Furnished">Furnished</option>
              <option value="Semi-Furnished">Semi-Furnished</option>
              <option value="Unfurnished">Unfurnished</option>
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Transaction</label>
            <select value={transaction} onChange={(e) => setTransaction(e.target.value)} required>
              <option value="New Property">New Property</option>
              <option value="Resale">Resale</option>
            </select>
          </div>

          <div className="form-group">
            <label>Ownership</label>
            <select value={ownership} onChange={(e) => setOwnership(e.target.value)} required>
              <option value="Freehold">Freehold</option>
              <option value="Leasehold">Leasehold</option>
              <option value="Co-operative Society">Co-operative Society</option>
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>Facing</label>
          <select value={facing} onChange={(e) => setFacing(e.target.value)} required>
            <option value="East">East</option>
            <option value="West">West</option>
            <option value="North">North</option>
            <option value="South">South</option>
            <option value="North-East">North-East</option>
            <option value="North-West">North-West</option>
            <option value="South-East">South-East</option>
            <option value="South-West">South-West</option>
          </select>
        </div>

        <button type="submit" disabled={loading} className="submit-btn">
          {loading ? 'Predicting...' : 'Predict Price'}
        </button>
      </form>

      {error && (
        <div className="error-message">
          <p>{error}</p>
        </div>
      )}

      {predictedPrice !== null && (
        <div className="result-card">
          <h2>Predicted Price</h2>
          <p className="price">₹ {(predictedPrice / 100000).toFixed(2)} Lac</p>
        </div>
      )}
    </div>
  )
}

export default App