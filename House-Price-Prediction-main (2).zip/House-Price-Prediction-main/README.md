# House Price Prediction Ecosystem

Welcome to the **House Price Prediction** project—a complete end-to-end Machine Learning ecosystem designed to estimate real estate prices with high accuracy. Built from the ground up, this repository encompasses data engineering, predictive modeling, a high-performance backend, and a modern, glassmorphism-styled frontend.

## 🚀 Project Architecture

The architecture is divided into three core pillars:

1. **Data Science & Machine Learning (`/notebooks`)**
   - **Data Processing Pipeline:** Handles missing values, cleans raw string currency/area values, and removes statistical outliers.
   - **Model Training:** Utilizes Scikit-Learn's `RandomForestRegressor` wrapped in a robust preprocessing `Pipeline` (including `SimpleImputer`, `StandardScaler`, and `OneHotEncoder`).
   - **Dataset:** Trained on a comprehensive dataset of over 180,000 diverse real estate properties across major cities.

2. **Backend Infrastructure (`/backend`)**
   - Built with **FastAPI** for lightning-fast, asynchronous request handling.
   - Automatically loads the serialized model (`house_price.pkl`) and categorical mappings (`locations.json`) into memory on startup.
   - Exposes a RESTful `/predict` endpoint that validates incoming JSON payloads using Pydantic.

3. **Frontend Application (`/frontend`)**
   - A highly responsive **React + TypeScript** web application powered by **Vite**.
   - **UI/UX Design:** Features a futuristic "dark mode" interface with vibrant cyan/blue glowing accents, glassmorphism containers, and fluid CSS animations.
   - Dynamically fetches available locations from the backend and provides instant visual feedback on predictions.

## ⚙️ Quick Start Guide

You can launch the entire ecosystem locally with a single command.

**Prerequisites:** Python 3.12+ and Node.js.

### One-Click Launch (Windows)
Simply double-click the `Run_Project.bat` file in the root directory. This script will:
1. Boot up the FastAPI backend on port 8000.
2. Start the Vite development server on port 5173.
3. Automatically open the web interface in your default browser.

### Manual Setup
If you prefer to run services manually:

**Backend:**
```bash
cd backend
python -m uvicorn main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm run dev
```

## 🧠 Technologies Used
*   **Machine Learning:** Python, Pandas, Scikit-Learn, Joblib, Jupyter.
*   **Backend:** FastAPI, Pydantic, Uvicorn.
*   **Frontend:** React (Hooks), TypeScript, Vite, Vanilla CSS.

## 📝 License
This project was designed and developed from scratch as a comprehensive demonstration of full-stack AI integration.
